import React from 'react'

const Grocery = () => {
  return (
    <div>
      <h1 style={{marginTop: '6rem', textAlign: 'center'}}>Our Grocery Online Store, we have a lot of child components inside this web page</h1>
    </div>
  )
}

export default Grocery
